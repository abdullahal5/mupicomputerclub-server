export interface IArticle {
  title: string;
  thumbnailImage: string;
  authorName: string;
  bio: string;
  content: string;
}
