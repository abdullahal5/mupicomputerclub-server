export interface ICommittee {
  year: string;
}
