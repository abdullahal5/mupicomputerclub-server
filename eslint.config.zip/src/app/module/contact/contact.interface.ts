export interface IContact {
  name: string;
  email: string;
  message: string;
}
