export interface IExecutives {
  profileImage: string;
  fullName: string;
  contact: string;
  email: string;
  communitySession: string;
  session: string;
  roleType: string;
  role: string;
  linkedin: string;
  facebook: string;
  twitter: string;
}
